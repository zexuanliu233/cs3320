import sys
data = open("message1.txt").read()
after1 = ""
after = ""
for ch in data:
    if ord(ch)>65 and ord(ch)<90:
        after1 = after1 + chr(ord(ch) + 32)
    else:
        after1 = after1 + ch
#upper to lower
for c in after1:
    if ord(c)>96 and ord(c)<114:
        after = after + chr(ord(c) + 9)
    elif ord(c)>113 and ord(c)<123 :
        after = after + chr(ord(c) - 17)
    else:
        after = after + c
print(after)
