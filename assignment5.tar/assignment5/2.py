import sys
data = open("ceaser1.txt").read()
after = ""
for c in data:
    if ord(c)>99 and ord(c)<123:
        after = after + chr(ord(c) - 3)
    elif ord(c)>96 and ord(c)<100:
        after = after + chr(ord(c) + 23)
    else:
        after = after + c
print(after)
