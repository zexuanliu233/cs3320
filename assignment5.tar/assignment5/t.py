import sys
data = open("message1.txt").read()
print(data)
