import sys
data = open("ceaser2.txt").read()
after = ""
for c in data:
    if ord(c)>102 and ord(c)<123:
        after = after + chr(ord(c) - 6)
    elif ord(c)>96 and ord(c)<103:
        after = after + chr(ord(c) + 20)
    else:
        after = after + c
print(after)
