c= int(input("Please the year:"))
if((c % 4 ==0 and c % 100 !=0) or c % 400 ==0):
    print("This is a leap year!")
else:
    print("This is not a leap year!")
