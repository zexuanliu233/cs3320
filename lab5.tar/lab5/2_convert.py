inp=raw_input("Please type your input:")
print("Your input is",ord(inp))
