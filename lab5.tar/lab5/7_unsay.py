number = raw_input("Type your input:")
flag = number.find("-")
if flag== -1:
    if number == "one":
        print("1")
    if number == "two":
        print("2")
    if number == "three":
        print("3")
    if number == "four":
        print("4")
    if number == "five":
        print("5")
    if number == "six":
        print("6")
    if number == "seven":
        print("7")
    if number == "eight":
        print("8")
    if number == "nine":
        print("9")
    if number == "ten":
        print("10")
    if number == "eleven":
        print("11")
    if number == "twelve":
        print("12")
    if number == "thirteen":
        print("13")
    if number == "fourteen":
        print("14")
    if number == "fifteen":
        print("15")
    if number == "sixteen":
        print("16")
    if number == "seventeen":
        print("17")
    if number == "eighteen":
        print("18")
    if number == "nineteen":
        print("19")
    if number == "twenty":
        print("20")
    if number == "thirty":
        print("30")
    if number == "forty":
        print("40")
    if number == "fifty":
        print("50")
    if number == "sixty":
        print("60")
    if number == "seventy":
        print("70")
    if number == "eighty":
        print("80")
    if number == "ninety":
        print("90")
else:
    x = number.split ("-")
    if x[0] == "twenty" :
        print "2",
    if   x[0] == "thirty": 
        print "3",
    if   x[0] == "forty": 
        print "4",
    if   x[0] == "fifty": 
        print "5",
    if   x[0] == "sixty": 
        print "6",
    if   x[0] == "seventy": 
        print "7",
    if   x[0] == "eighty": 
        print "8",
    if   x[0] == "ninety": 
        print "9",
    if   x[1] == "one": 
        print "1",
    if   x[1] == "two": 
        print "2",
    if   x[1] == "three": 
        print "3",
    if   x[1] == "four": 
        print "5",
    if   x[1] == "five": 
        print "5",
    if   x[1] == "six": 
        print "6",
    if   x[1] == "seven": 
        print "7",
    if   x[1] == "eight": 
        print "8",
    if   x[1] == "nine": 
        print "9",
