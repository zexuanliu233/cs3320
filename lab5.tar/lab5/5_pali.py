i = 99*999
flag = True
while flag:
    a = int(i/ 10000)
    b = int((i/ 1000) % 10)
    c = int((i / 100) % 10)
    d = int((i / 10) % 10)
    e = int(i % 10)
    j = e*10000 + d *1000 + c*100 + b*10 + a
    if(j==i):
        flag=False
        print(j)
    i = i - 1
