sum=0
for num in range(0,1000):
    if(num%3==0 or num%5==0):
        sum+=num
print("The sum of all the integers below 1000 that are multiples of 3 or 5 is " , sum)
