number = raw_input("Type your first input:")
i=1
mul = [1, 1, 1]
while i<3:
    flag = number.find("-")
    if flag== -1:
        if number == "one":
            mul[i] = 1
        if number == "two":
            mul[i] = 2
        if number == "three":
            mul[i] = 3
        if number == "four":
            mul[i] = 4 
        if number == "five":
            mul[i] = 5 
        if number == "six":
            mul[i] = 6 
        if number == "seven":
            mul[i] = 7 
        if number == "eight":
            mul[i] = 8 
        if number == "nine":
            mul[i] = 9 
        if number == "ten":
            mul[i] = 10 
        if number == "eleven":
            mul[i] = 11 
        if number == "twelve":
            mul[i] = 12 
        if number == "thirteen":
            mul[i] = 13 
        if number == "fourteen":
            mul[i] = 14 
        if number == "fifteen":
            mul[i] = 15 
        if number == "sixteen":
            mul[i] = 16 
        if number == "seventeen":
            mul[i] = 17 
        if number == "eighteen":
            mul[i] = 18 
        if number == "nineteen":
            mul[i] = 19 
        if number == "twenty":
            mul[i] = 20 
        if number == "thirty":
            mul[i] = 30 
        if number == "forty":
            mul[i] = 40 
        if number == "fifty":
            mul[i] = 50 
        if number == "sixty":
            mul[i] = 60 
        if number == "seventy":
            mul[i] = 70 
        if number == "eighty":
            mul[i] = 80 
        if number == "ninety":
            mul[i] = 90 
    else:
        x = number.split ("-")
        if x[0] == "twenty" :
            mul[i] = 20
        if   x[0] == "thirty":
            mul[i] = 30
        if   x[0] == "forty":
            mul[i] = 40
        if   x[0] == "fifty":
            mul[i] = 50
        if   x[0] == "sixty":
            mul[i] = 60
        if   x[0] == "seventy":
            mul[i] = 70
        if   x[0] == "eighty":
            mul[i] = 80
        if   x[0] == "ninety":
            mul[i] = 90
        if   x[1] == "one":
            mul[i] = mul[i] + 1
        if   x[1] == "two":
            mul[i] = mul[i] +2
        if   x[1] == "three":
            mul[i] = mul[i] + 3
        if   x[1] == "four":
            mul[i] = mul[i] + 4
        if   x[1] == "five":
            mul[i] = mul[i] + 5
        if   x[1] == "six":
            mul[i] = mul[i] + 6
        if x[1] == "seven":
            mul[i] = mul[i] + 7
        if x[1] == "eight":
            mul[i] = mul[i] + 8
        if x[1] == "nine":
            mul[i] = mul[i] + 9
    i = i +1
    if i==2:
        number = raw_input("Type your second input:")
print(mul[1]*mul[2])
