number = int(input("Please type your input:"))
t = int(number/10)
u = number%10
if(t<2):
    if(number==1):
        print("one")
    if(number==2):
        print("two")
    if(number==3):
        print("three")
    if(number==4):
        print("four")
    if(number==5):
        print("five")
    if(number==6):
        print("six")
    if(number==7):
        print("seven")
    if(number==8):
        print("eight")
    if(number==9):
        print("nine")
    if(number==10):
        print("ten")
    if(number==11):
        print("eleven")
    if(number==12):
        print("twelve")
    if(number==13):
        print("thirteen")
    if(number==14):
        print("fourteen")
    if(number==15):
        print("fifteen")
    if (number == 16):
        print("sicteen")
    if (number == 17):
        print("seventeen")
    if (number == 18):
        print("eighteen")
    if (number == 19):
        print("nineteen")
if (t >= 2):
    if (t == 2):
        print "twenty",
    if (t == 3):
        print "thirty",
    if (t == 4):
        print "forty",
    if (t == 5):
        print "fifty",
    if (t == 6):
        print "sixty",
    if (t == 7):
        print "seventy",
    if (t == 8):
        print "eighty",
    if (t == 9):
        print "ninety",
    if (u == 1):
        print("-one")
    if (u == 2):
        print("-two")
    if (u == 3):
        print("-three")
    if (u == 4):
        print("-four")
    if (u == 5):
        print("-five")
    if (u == 6):
        print("-six")
    if (u == 7):
        print("-seven")
    if (u == 8):
        print("-eight")
    if (u == 9):
        print("-nine")

