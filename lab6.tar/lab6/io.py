from os import system
binary_data1 = open("bina.txt","rb")
read = binary_data1.read()
binary_data2 = open("bina.txt","wb")
wrte = binary_data2.write(b'Hello')
binary_data1.close()
binary_data2.close()
