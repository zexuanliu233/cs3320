import binascii
def dehexify(hexfilepath):
    data = open(hexfilepath, "r").read()
    print(data)
    unhex = binascii.unhexlify(data)
    print(unhex)
dehexify("hex_dump")
