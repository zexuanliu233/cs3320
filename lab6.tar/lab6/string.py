import binascii
ip = raw_input("enter a string")
print("cover to binary")
bip = binascii.a2b_base64(ip.strip())
print(bip)
print("conver back to string")
back_ip = binascii.b2a_base64(bip)
print(back_ip)
