#include<stdio.h>
int main(){
	int i,sum=0;
	for(i;i<1000;i++){
		if((i%3==0)||(i%5==0)){
			sum+=i;
		}
	}
	printf("Sum is %d\n",sum); 
	return 0;	
}
