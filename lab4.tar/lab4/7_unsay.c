#include<stdio.h>
#include<string.h>
int main(){	
	char number[20];
	printf("Type your input(zero,hundred): ");
	scanf("%s",number);
	const char needle[2] = "-";
	char *ret;
	ret = strstr(number, needle); //try to find out if the input contains "-"
	if(!ret){
		if(strcmp(number,"one")==0) printf("1");
		if(strcmp(number,"two")==0) printf("2");
		if(strcmp(number,"three")==0) printf("3");
		if(strcmp(number,"four")==0) printf("4");
		if(strcmp(number,"five")==0) printf("5");
		if(strcmp(number,"six")==0) printf("6");
		if(strcmp(number,"seven")==0) printf("7");
		if(strcmp(number,"eight")==0) printf("8");
		if(strcmp(number,"nine")==0) printf("9");
		if(strcmp(number,"ten")==0) printf("10");
		if(strcmp(number,"eleven")==0) printf("11");
		if(strcmp(number,"twelve")==0) printf("12");
		if(strcmp(number,"thirteen")==0) printf("13");
		if(strcmp(number,"fourteen")==0) printf("14");
		if(strcmp(number,"fifteen")==0) printf("15");
		if(strcmp(number,"sixteen")==0) printf("16");
		if(strcmp(number,"seventeen")==0) printf("17");
		if(strcmp(number,"eighteen")==0) printf("18");
		if(strcmp(number,"nineteen")==0) printf("19");
		if(strcmp(number,"twenty")==0) printf("20");
		if(strcmp(number,"thirty")==0) printf("30");
		if(strcmp(number,"forty")==0) printf("40");
		if(strcmp(number,"fifty")==0) printf("50");
		if(strcmp(number,"sixty")==0) printf("60");
		if(strcmp(number,"seventy")==0) printf("70");
		if(strcmp(number,"eighty")==0) printf("80");
		if(strcmp(number,"ninety")==0) printf("90");
	}else{
		char *ten;
		char *unit;
		ten=strtok(number,needle);
		unit=strtok(NULL,needle);
		if(strcmp(ten,"twenty")==0) printf("2");
		if(strcmp(ten,"thirty")==0) printf("3");
		if(strcmp(ten,"forty")==0) printf("4");
		if(strcmp(ten,"fifty")==0) printf("5");
		if(strcmp(ten,"sixty")==0) printf("6");
		if(strcmp(ten,"seventy")==0) printf("7");
		if(strcmp(ten,"eighty")==0) printf("8");
		if(strcmp(ten,"ninety")==0) printf("9");
		if(strcmp(unit,"one")==0) printf("1");
		if(strcmp(unit,"two")==0) printf("2");
		if(strcmp(unit,"three")==0) printf("3");
		if(strcmp(unit,"four")==0) printf("4");
		if(strcmp(unit,"five")==0) printf("5");
		if(strcmp(unit,"six")==0) printf("6");
		if(strcmp(unit,"seven")==0) printf("7");
		if(strcmp(unit,"eight")==0) printf("8");
		if(strcmp(unit,"nine")==0) printf("9");
	}
   printf("\n");
   return(0);
} 
