#include<stdio.h>
int main(){
	int i=99*999;
	int flag=1;
	int a,b,c,d,e,j;
	while(flag&&(i>0)){
		a=i/10000;
		b=(i%10000)/1000;
		c=(i%1000)/100;
		d=(i%100)/10;
		e=i-10000*a-1000*b-100*c-10*d;
		j=10000*e+1000*d+100*c+10*b+a;
		if(i==j){
			printf("The largest palindrome made by the product of two and three digit numbers is: %d.\n",j);
			flag=0;
		}
		i--;
	}
	return 0;	
}
