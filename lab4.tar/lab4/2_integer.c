#include<stdio.h>
int main(){
	printf("Type your input:\n") ;
	char input[20];
	scanf("%s",input);
	printf("Your converted input is: %d\n",input);
	return 0;	
}
