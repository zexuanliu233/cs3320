#include<stdio.h>
int main(){
	printf("Type your input:\n") ;
	char input[20];
	scanf("%s",input);
	printf("Your input is: %s\n",input);
	return 0;
	
}

