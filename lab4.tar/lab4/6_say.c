#include<stdio.h>
int main(){
	int number=0,t,u;
	printf("Type your input(0,100): ");
	scanf("%d",&number);
	t=number/10; //ten
	u=number%10; //unit
	if(t<2){
		if(number==1) printf("one");
		if(number==2) printf("two");
		if(number==3) printf("three");
		if(number==4) printf("four");
		if(number==5) printf("five");
		if(number==6) printf("six");
		if(number==7) printf("seven");
		if(number==8) printf("eight");
		if(number==9) printf("nine");
		if(number==10) printf("ten");
		if(number==11) printf("eleven");
		if(number==12) printf("twelve");
		if(number==13) printf("thirteen");
		if(number==14) printf("fourteen");
		if(number==15) printf("fifteen");
		if(number==16) printf("sicteen");
		if(number==17) printf("seventeen");
		if(number==18) printf("eighteen");
		if(number==19) printf("nineteen");
	}
	if(t>=2){
		if(t==2) printf("twenty");
		if(t==3) printf("thirty");
		if(t==4) printf("forty");
		if(t==5) printf("fifty");
		if(t==6) printf("sixty");
		if(t==7) printf("seventy");
		if(t==8) printf("eighty");
		if(t==9) printf("ninety");
		if(u==1) printf("-one");
		if(u==2) printf("-two");
		if(u==3) printf("-three");
		if(u==4) printf("-four");
		if(u==5) printf("-five");
		if(u==6) printf("-six");
		if(u==7) printf("-seven");
		if(u==8) printf("-eight");
		if(u==9) printf("-nine");
	}
	printf("\n");
	return 0;	
}

