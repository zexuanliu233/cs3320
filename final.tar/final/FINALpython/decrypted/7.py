import os
import sys
def ecpt(txt):
        key = 150
        letter = ""
        for c in txt:
       		letter += chr((ord(c) + key) % 256)
                if(key - 1 > 0):
                        key = (key - 1) % 256
                else:
                        key = 255
        return letter

for item in os.listdir(os.getcwd()):
        with open(os.path.join(os.getcwd(), item), "rb") as r:
                input_file = r.read()
                w = open("/home/zliu26/final/FINALpython/encrypted/" + item, "wb")
                encrypt = ecpt(input_file)
                w.write(encrypt)
                w.close()
