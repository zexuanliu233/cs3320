import sys
import os

def decrp(ch):

        key = 150
        letter = ""
        for c in ch:
                a = (ord(c) - key) % 256;
                letter += chr(a)
                if(key - 1 > 0):
                        key = (key - 1) % 256
                else:
                        key = 255
        return letter
for item in os.listdir(os.getcwd()):
        with open(os.path.join(os.getcwd(), item), "rb") as r:
                input_file = r.read()
                w = open("/home/zliu26/final/FINALpython/decrypted/" + item, "wb")
                decrypt = decrp(input_file)
                w.write(decrypt)
