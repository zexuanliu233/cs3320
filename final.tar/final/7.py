import sys
import os
def encry(txt):
    key = 150
    letter = ""
    for ch in txt:
        #ch.lower()
        #if(ord(ch)>=ord('a') and ord(ch) <= ord('z')):
        letter = letter + chr((ord(ch) + key) % 256)
        #else:
        #    letter = letter + ch
        if(key -1 > 0):
            key = (key - 1 )% 256
        else:
            key = 255
    return letter
for item in os.listdir(os.getcwd()):
    with open(os.path.join(os.getcwd(),item),"rb") as r:
        input_file = r.read()
        w = open("FINALpython/encrypted/" + item, "wb")
        encrypt = encry(input_file)
        w.write(encrypt)
        w.close()
