import os
import shutil
scr = "/home/zliu26/final/1.py"
dst = "/home/zliu26/final/FINALpython/1.py"
path = "/home/zliu26/final/FINALpython"
sub_path1 = "/home/zliu26/final/FINALpython/copies"
sub_path2 = "/home/zliu26/final/FINALpython/encrypted"
sub_path3 = "/home/zliu26/final/FINALpython/decrypted"

try:
    os.mkdir(path)
except OSError:
    print("Creation of the directory", path, "is failed")
else:
    print("Successfully created the directory", path)

try:
    os.mkdir(sub_path1)
except OSError:
    print("Creation of the directory", sub_path1, "is failed")
else:
    print("Successfully created the directory", sub_path1)

try:
    os.mkdir(sub_path2)
except OSError:
    print("Creation of the directory", sub_path2, "is failed")
else:
    print("Successfully created the directory", sub_path2)

try:
    os.mkdir(sub_path3)
except OSError:
    print("Creation of the directory", sub_path3, "is failed")
else:
    print("Successfully created the directory", sub_path3)

try:
    shutil.copy(scr, dst)
except OSError:
    print("Copy of the code", scr, "is failed")
else:
    print("Successfully copied the code", scr)
