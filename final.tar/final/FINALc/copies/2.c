#include <sys/types.h> 
#include <sys/stat.h> 
#include <unistd.h> 
#include <stdio.h> 
#include <stdlib.h> 
  
void main() 
{ 
    int dir = mkdir("FINALc",0777);
    mkdir("FINALc/copies",0777);
    mkdir("FINALc/encrypted",0777);
    mkdir("FINALc/decrypted",0777);
    system("cp 2.c FINALc");
} 
