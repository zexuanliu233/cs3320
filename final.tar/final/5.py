import shutil, os
files = ['1.py','2.c','2.out','4.sh','a.out','FINALinstruction','output']
for f in files:
    shutil.copy(f,'FINALpython/copies')
    shutil.copy(f,'FINALc/copies')
