#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char **argv){
    DIR* dir;
    struct dirent* in_file;
    FILE    *common_file;
    FILE    *entry_file;
    char    buffer[BUFSIZ];
    int key = 150;

    dir = opendir("FINALc/encrypted"); 
    while ((in_file = readdir(dir))!=NULL) 
    {
        if (!strcmp (in_file->d_name, "."))
            continue;
        if (!strcmp (in_file->d_name, ".."))    
            continue;
            
        entry_file = fopen(in_file->d_name, "rb");
        
        while (fgets(buffer, BUFSIZ, entry_file) != NULL)
        {
            char s1[20] = "FINALc/decrypted/";
            char s2[20];
            strcpy(s2,in_file->d_name);
            strcat(s1,s2);
            common_file = fopen(s1, "w");

            fread(buffer,BUFSIZ,1,entry_file);
            char out[BUFSIZ];
            int i;
            for(i = 0; i < BUFSIZ; i++){
		key = key - 1 > 0 ? ( key - 1 ) % 256 : 255;
                out[i] = buffer[i] - key;
            }

            fwrite(out,BUFSIZ,1,common_file);
            fclose(common_file);
            
        }
        fclose(entry_file);
    }
    closedir(dir);
    return 0;
}

