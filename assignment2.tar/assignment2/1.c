#include<stdio.h>
int main(){
        int i;
        char txt[10000];
        FILE *fp;
        fp=fopen("message1.txt","r");
        for(i=0;i<10000;i++) fscanf(fp,"%c",&txt[i]);
        fclose(fp);
        i=0;
        while(txt[i]){
			if(txt[i]>64&&txt[i]<91) txt[i]+=32;//upper to lower

            if(txt[i]>96&&txt[i]<123){
                if(txt[i]>96&&txt[i]<114) txt[i]+=9;
				else txt[i]-=17;
			}	
			i++;        
        }
        printf("%s",txt);
        return 0;
}
