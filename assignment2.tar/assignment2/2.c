#include<stdio.h>
int main(){
	int count[123];
	int c=0;
	for(c;c<123;c++) count[c]=0;	
	char txt[10000];
	FILE *fp;
	fp=fopen("ceaser1.txt","r");
	int i;
	for(i=0;i<10000;i++) fscanf(fp,"%c",&txt[i]);
	fclose(fp);	
	i=0;
	while(txt[i]){
		count[txt[i]]++; 		
		if(txt[i]>96&&txt[i]<123) {
        	if(txt[i]>99&&txt[i]<123){
        		txt[i]-=3;
			}else{
				txt[i]+=23;
			}       		
		}
		i++;   						
	}
	for(c=97;c<123;c++){
		printf("The number of %c is %d\n",c,count[c]);
	}
	printf("%s",txt);
	return 0;
} 
